import React from 'react';
import { Heart, Trash2, ShoppingCart } from 'lucide-react';
import { useStore } from '../store/useStore';

export function Wishlist({ onClose }: { onClose: () => void }) {
  const { wishlist, removeFromWishlist, addToCart } = useStore();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Heart className="text-red-500" /> Wishlist
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            ×
          </button>
        </div>
        
        {wishlist.length === 0 ? (
          <p className="text-center text-gray-500 py-8">
            Your wishlist is empty
          </p>
        ) : (
          <div className="grid gap-4">
            {wishlist.map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-4 p-4 border rounded-lg"
              >
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-20 h-20 object-cover rounded"
                />
                <div className="flex-1">
                  <h3 className="font-semibold">{item.name}</h3>
                  <p className="text-gray-600">${item.price.toFixed(2)}</p>
                  <p className="text-sm text-gray-500">
                    Added on {new Date(item.dateAdded).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      addToCart(item);
                      removeFromWishlist(item.id);
                    }}
                    className="p-2 text-purple-600 hover:bg-purple-50 rounded"
                    title="Add to Cart"
                  >
                    <ShoppingCart size={20} />
                  </button>
                  <button
                    onClick={() => removeFromWishlist(item.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded"
                    title="Remove from Wishlist"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}