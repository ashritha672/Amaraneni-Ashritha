import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Product, CartItem, Order, WishlistItem } from '../types';

interface StoreState {
  cart: CartItem[];
  orders: Order[];
  wishlist: WishlistItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  addToWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  placeOrder: (paymentMethod: string) => void;
  cancelOrder: (orderId: string) => void;
  clearCart: () => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set) => ({
      cart: [],
      orders: [],
      wishlist: [],

      addToCart: (product) =>
        set((state) => {
          const existingItem = state.cart.find((item) => item.id === product.id);
          if (existingItem) {
            return {
              cart: state.cart.map((item) =>
                item.id === product.id
                  ? { ...item, quantity: item.quantity + 1 }
                  : item
              ),
            };
          }
          return { cart: [...state.cart, { ...product, quantity: 1 }] };
        }),

      removeFromCart: (productId) =>
        set((state) => ({
          cart: state.cart.filter((item) => item.id !== productId),
        })),

      updateCartQuantity: (productId, quantity) =>
        set((state) => ({
          cart: state.cart.map((item) =>
            item.id === productId ? { ...item, quantity } : item
          ),
        })),

      addToWishlist: (product) =>
        set((state) => ({
          wishlist: [
            ...state.wishlist,
            { ...product, dateAdded: new Date().toISOString() },
          ],
        })),

      removeFromWishlist: (productId) =>
        set((state) => ({
          wishlist: state.wishlist.filter((item) => item.id !== productId),
        })),

      placeOrder: (paymentMethod) =>
        set((state) => ({
          orders: [
            ...state.orders,
            {
              id: Math.random().toString(36).substr(2, 9),
              items: [...state.cart],
              total: state.cart.reduce(
                (sum, item) => sum + item.price * item.quantity,
                0
              ),
              status: 'pending',
              date: new Date().toISOString(),
              paymentMethod,
            },
          ],
          cart: [],
        })),

      cancelOrder: (orderId) =>
        set((state) => ({
          orders: state.orders.map((order) =>
            order.id === orderId ? { ...order, status: 'cancelled' } : order
          ),
        })),

      clearCart: () => set({ cart: [] }),
    }),
    {
      name: 'store',
    }
  )
);