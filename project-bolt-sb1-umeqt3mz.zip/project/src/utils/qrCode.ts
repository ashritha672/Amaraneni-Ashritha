import QRCode from 'qrcode';
import { Order } from '../types';

export async function generateQRCode(order: Order) {
  const orderData = {
    orderId: order.id,
    date: order.date,
    items: order.items.map(item => ({
      name: item.name,
      quantity: item.quantity,
      price: item.price
    })),
    total: order.total,
    paymentMethod: order.paymentMethod
  };

  try {
    const url = await QRCode.toDataURL(JSON.stringify(orderData));
    const link = document.createElement('a');
    link.download = `order-${order.id}-qr.png`;
    link.href = url;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } catch (err) {
    console.error('Error generating QR code:', err);
  }
}