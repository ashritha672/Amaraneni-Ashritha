export const products = [
  {
    id: '1',
    name: 'Organic Fresh Milk',
    price: 3.99,
    description: 'Farm-fresh organic milk, perfect for your daily needs.',
    image: 'https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&q=80&w=1000',
    stock: 50,
    isPreorderable: false
  },
  {
    id: '2',
    name: 'Whole Grain Bread',
    price: 4.49,
    description: 'Freshly baked whole grain bread with natural ingredients.',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=1000',
    stock: 30,
    isPreorderable: true,
    preorderDate: '2024-04-01'
  },
  {
    id: '3',
    name: 'Free Range Eggs',
    price: 5.99,
    description: 'Farm-fresh free-range eggs from happy chickens.',
    image: 'https://images.unsplash.com/photo-1518569656558-1f25e69d93d7?auto=format&fit=crop&q=80&w=1000',
    stock: 40,
    isPreorderable: false
  },
  {
    id: '4',
    name: 'Organic Honey',
    price: 8.99,
    description: 'Pure organic honey from local beekeepers.',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&q=80&w=1000',
    stock: 20,
    isPreorderable: true,
    preorderDate: '2024-03-25'
  }
];