import React, { useState } from 'react';
import { ShoppingBag, Heart, Clock, Package } from 'lucide-react';
import { ProductCard } from './components/ProductCard';
import { Cart } from './components/Cart';
import { Checkout } from './components/Checkout';
import { Wishlist } from './components/Wishlist';
import { OrderHistory } from './components/OrderHistory';
import { useStore } from './store/useStore';
import { products } from './data/products';

function App() {
  const [showCart, setShowCart] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [showWishlist, setShowWishlist] = useState(false);
  const [showOrders, setShowOrders] = useState(false);
  const { cart } = useStore();

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-purple-600">Daily Products Store</h1>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowWishlist(true)}
              className="p-2 text-gray-600 hover:text-purple-600"
              title="Wishlist"
            >
              <Heart size={24} />
            </button>
            <button
              onClick={() => setShowOrders(true)}
              className="p-2 text-gray-600 hover:text-purple-600"
              title="Orders"
            >
              <Package size={24} />
            </button>
            <button
              onClick={() => setShowCart(true)}
              className="relative p-2 text-gray-600 hover:text-purple-600"
              title="Cart"
            >
              <ShoppingBag size={24} />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-purple-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                  {cart.reduce((sum, item) => sum + item.quantity, 0)}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </main>

      {showCart && <Cart onClose={() => setShowCart(false)} onCheckout={() => {
        setShowCart(false);
        setShowCheckout(true);
      }} />}
      
      {showCheckout && <Checkout onClose={() => setShowCheckout(false)} />}
      
      {showWishlist && <Wishlist onClose={() => setShowWishlist(false)} />}
      
      {showOrders && <OrderHistory onClose={() => setShowOrders(false)} />}
    </div>
  );
}

export default App;